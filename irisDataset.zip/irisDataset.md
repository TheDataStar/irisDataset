

```R
# Loading dataset.
iris <- ("iris.csv")
data(iris)
head(iris)
```


<table>
<thead><tr><th scope=col>Sepal.Length</th><th scope=col>Sepal.Width</th><th scope=col>Petal.Length</th><th scope=col>Petal.Width</th><th scope=col>Species</th></tr></thead>
<tbody>
	<tr><td>5.1   </td><td>3.5   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.9   </td><td>3.0   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.7   </td><td>3.2   </td><td>1.3   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>4.6   </td><td>3.1   </td><td>1.5   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.0   </td><td>3.6   </td><td>1.4   </td><td>0.2   </td><td>setosa</td></tr>
	<tr><td>5.4   </td><td>3.9   </td><td>1.7   </td><td>0.4   </td><td>setosa</td></tr>
</tbody>
</table>




```R
# Showing dataset dimensions.
dim(iris)
```


<ol class=list-inline>
	<li>150</li>
	<li>5</li>
</ol>




```R
# Summary of iris dataset, provides minimum, maximum, median, mean, Q1, and Q3 of all numerical features.
summary(iris)
```


      Sepal.Length    Sepal.Width     Petal.Length    Petal.Width   
     Min.   :4.300   Min.   :2.000   Min.   :1.000   Min.   :0.100  
     1st Qu.:5.100   1st Qu.:2.800   1st Qu.:1.600   1st Qu.:0.300  
     Median :5.800   Median :3.000   Median :4.350   Median :1.300  
     Mean   :5.843   Mean   :3.057   Mean   :3.758   Mean   :1.199  
     3rd Qu.:6.400   3rd Qu.:3.300   3rd Qu.:5.100   3rd Qu.:1.800  
     Max.   :7.900   Max.   :4.400   Max.   :6.900   Max.   :2.500  
           Species  
     setosa    :50  
     versicolor:50  
     virginica :50  
                    
                    
                    



```R
boxplot(Sepal.Length ~ Species, data=iris, main="Speal Length of various species", xlab="Species", ylab="Sepal Length", col = c("blue", "green", "red"))
```


![png](output_3_0.png)



```R
# Data formatted into notched boxplot using Petal Length instead of Sepal Length.
boxplot(Petal.Length ~ Species, data=iris, main="Petal Length", xlab="Species", ylab="Petal Length", notch=TRUE, col =c("blue", "green", "red"))
```


![png](output_4_0.png)



```R
# Saving plots (this example turns it into a pdf file). To be used in IDE such as Rstudio.
pdf(''iris.pdf'')
boxplot(Petal.Length ~ Species, data=iris, main="Petal Length", xlab="Species", ylab="Petal Length", notch=TRUE, col =c("blue", "green", "red"))
def.off() #returns plot to IDE
```


    Error in parse(text = x, srcfile = src): <text>:2:7: unexpected symbol
    1: # Saving plots (this example turns it into a pdf file)
    2: pdf(''iris.pdf
             ^
    Traceback:
    



```R
# The plot function is used to plot two numerical variables and helps in determining a relationship between them. Does not allow for differentiation between species.
plot(Sepal.Length ~ Sepal.Width, data=iris, xlab="Sepla Length", ylab="Sepal Width", main="Scatterplot of Speal width v. Length")
```


![png](output_6_0.png)



```R
# Lattice graphics, xyplot function.
install.packages("lattice")
library(lattice)
xyplot(Sepal.Width ~ Sepal.Length, data=iris, groups=Species, auto.key=list(corner=c(0,0), x=0, y=0.85, cex=1.5), cex=1.5, scales=list(cex=1.5))
```

    Warning message:
    "package 'lattice' is in use and will not be installed"


![png](output_7_1.png)



```R
# compaer and contrast of 2d scatterplot with regression line on plot.
plot(Petal.Length ~ Petal.Width, data=iris, main="Pedal Width v. Length")
abline(lm(Petal.Length ~ Petal.Width, data=iris), col="blue")
```


![png](output_8_0.png)



```R
# correlation coefficient between variables.
cor(iris$Petal.Width, iris$Petal.Length)
```


0.962865431402796



```R
#2d scatterplot comparison with lattice graphics.
xyplot(Petal.Width ~ Petal.Length, data=iris, groups= Species, auto.key=list(corner=c(0,0), x=0, y=0.85, cex=1.5), cex=1.5, scales=list(cex=1.5))
xyplot(Petal.Width ~ Petal.Length, data=iris, groups=Species, auto.key=TRUE)
```


![png](output_10_0.png)



![png](output_10_1.png)



```R
# Histogram
hist(iris$Petal.Length)
hist(iris$Petal.Length, breaks=12, col="purple")
```


![png](output_11_0.png)



![png](output_11_1.png)



```R
# Lattice graphics
histogram(iris$Petal.Length, breaks=12, type="count", main="Histogram")
```


![png](output_12_0.png)



```R
# A density plot function is a variation on the histogram and estimates densities for data.
# the points at the bottom of the graph represents the actual density of the points that relate to the peaks of the graph.
densityplot(iris$Petal.Length)
```


![png](output_13_0.png)

